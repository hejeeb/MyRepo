# kubernetes-project
A project to deploy Wordpress application on Kubernets using CI/CD pipeline
